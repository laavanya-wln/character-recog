clear;close all;clc;
load '-ascii' 'threes'
result = my_pca2(threes);
getImage(5*result.w(:,1),'First Eigenvector')
getImage(5*result.w(:,2),'Second Eigenvector')
getImage(5*result.w(:,3),'Third Eigenvector')
getImage(5*result.w(:,4),'Fourth Eigenvector')
getImage(5*result.w(:,5),'Fifth Eigenvector')
getImage(5*result.w(:,6),'Sixth Eigenvector')
getImage(result.reconstructions(1).Xp(1,:),'Reconstruction of First Image Based on Top Eigenvector')
getImage(result.reconstructions(2).Xp(1,:),'Reconstruction of First Image Based on Top 2 Eigenvectors')
getImage(result.reconstructions(3).Xp(1,:),'Reconstruction of First Image Based on Top 3 Eigenvectors')
getImage(result.reconstructions(4).Xp(1,:),'Reconstruction of First Image Based on Top 4 Eigenvectors')