function result=my_pca2(X)
    ZX = bsxfun(@minus, X, mean(X));
    C = cov(ZX);
    [w,lam] = eig(C);
    lam = diag(lam);
    [lam,IDX]=sort(lam,'descend');
    w = w(:,IDX);
    result.w = w;
    result.lambdas = lam; 
    result.varfracs = cumsum(lam/sum(lam));
    figure, hold on;
    plot(lam);
    xlabel('Index');
    ylabel('Eigenvalue');
    title('PCA Eigenvalue Plot');
    hold off;
    figure, hold on;
    plot(result.varfracs);
    xlabel('Number of Principal Components');
    ylabel('Fraction of Variance Captured');
    title('PCA Variance Plot');
    hold off;
    for i=1:max(size(lam))
        Xq = ZX*w(:,1:i);
        Xp = (w(:,1:i)*(Xq'))';
        Xp = bsxfun(@minus, Xp, -mean(X));
        result.projections(i).Xq = Xq;
        result.reconstructions(i).Xp = Xp;
        result.error(i) = sum(sum((X-Xp).^2));
    end
    figure, hold on;
    plot(result.error);
    xlabel('Number of Principal Components');
    ylabel('Reconstruction Error');
    title('PCA Reconstruction Error Plot');
    hold off;
end
