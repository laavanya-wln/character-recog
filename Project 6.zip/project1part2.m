function [best1,best2]=project1part2()
    [Xtrain,Ytrain,Xtest,Ytest]=getDataset();
    [ccr1,ccrv1,best1,resultData1] = firstExperiment(Xtrain,Ytrain,Xtest,Ytest);
    best1.ccr
    [ccr2,ccrv2,best2,resultData2] = secondExperiment(Xtrain,Ytrain,Xtest,Ytest);
    best2
    netfig(best1.net,'classjust.png');
    netfig(best2.net,'classpca.png');
end

function [ccr,ccrv,best,resultData] = secondExperiment(Xtrain,Ytrain,Xtest,Ytest)
    W = PCA(Xtrain);
    hidunits = [10 50 100];
    for k=2:size(Xtrain,1)
        for i=1:max(size(hidunits))
                [rXtrain,rXtest] = dimensionalityReduction(Xtrain,Xtest,W,k);
                [net,tr] = ffnnOperations(rXtrain,Ytrain,hidunits(i),'tansig');
                ccrv(i,k-1) = tr.best_vperf;
                [ccr(i,k-1),cmat] = computeError(net,rXtest,Ytest);
                resultData(i,k-1).net = net;
                resultData(i,k-1).tr = tr;
                resultData(i,k-1).cmat = cmat;
        end
    end
    [~, minidx] = min(ccrv(:));
    [minidx_i,minidx_j] = ind2sub(size(ccrv),minidx);
    best= resultData(minidx_i,minidx_j);
    best.ccr = ccr(minidx_i,minidx_j);
    best.k = 1+minidx_j;
    best.ccrv = ccrv(minidx_i,minidx_j);
end

function [ccr,ccrv,best,resultData] = firstExperiment(Xtrain,Ytrain,Xtest,Ytest)
    hidunits = [10 50 100];
    for i=1:max(size(hidunits))
            [net,tr] = ffnnOperations(Xtrain,Ytrain,hidunits(i),'tansig');
            ccrv(i) = tr.best_vperf;
            [ccr(i),cmat] = computeError(net,Xtest,Ytest);
            resultData(i).net = net;
            resultData(i).tr = tr;
            resultData(i).cmat = cmat;
    end
    [~, minidx] = min(ccrv);
    best= resultData(minidx);
    best.ccr = ccr(minidx);
    best.ccrv = ccrv(minidx);
end

function W = PCA(Xtrain)
    X = Xtrain';
    ZX = bsxfun(@minus, X, mean(X));
    [W,lam] = eig(cov(ZX));
    lam = diag(lam);
    [lam,idx]=sort(lam,'descend');
    W = W(:,idx);
    varfracs = cumsum(lam/sum(lam));
    figure, hold on;
    plot(lam);
    xlabel('Index');
    ylabel('Eigenvalue');
    title('PCA Eigenvalue Plot');
    hold off;
    figure, hold on;
    plot(varfracs);
    xlabel('Number of Principal Components');
    ylabel('Fraction of Variance Captured');
    title('PCA Variance Plot');
    hold off;
end


function [rXtrain,rXtest] = dimensionalityReduction(Xtrain,Xtest,W,nc)
    X = Xtrain';
    ZX = bsxfun(@minus, X, mean(X));
    Xt = Xtest';
    Ztest = bsxfun(@minus, Xt, mean(Xt));
    W = W(:,1:nc);
    rXtrain = (ZX*W)';
    rXtest = (Ztest*W)';
end

function [ccr,cmat] = computeError(net,Xtest,Ytest)
    Ypred=net(Xtest);
    cmat=confusionmat(Ypred(1,:)>0.5,Ytest(1,:)>0.5);
    ccr = sum(diag(cmat))/sum(sum(cmat));
end

function [net,tr]=ffnnOperations(X,Y,h,htrans)
    net = patternnet(h);
    net.divideFcn = 'dividerand';
    net.divideParam.trainRatio = 85/100;
    net.divideParam.valRatio = 15/100;
    net.divideParam.testRatio = 0/100;
    net.trainParam.showWindow=0;
    net.trainParam.epochs=10000;
    net.layers{1}.transferFcn = htrans;
    net.layers{2}.transferFcn = 'softmax';
    net.performFcn = 'crossentropy';
    [net,tr] = train(net,X,Y);
end

function [Xtrain,Ytrain,Xtest,Ytest]=getDataset()
    %Student Number: (r069080)9 => Red, C+=5,C-=6,7,8
    dataset = importdata('winequality-red.csv');
    subsetind = (dataset.data(:,12)==5 | dataset.data(:,12)==6 | dataset.data(:,12)==7 | dataset.data(:,12)==8);
    X=dataset.data(subsetind,1:(end-1))';
    y=dataset.data(subsetind,end);
    y(y~=5) = 0;
    y(y==5) = 1;
    Y = [y ~y]'; 
    [trainInd,~,testInd] = dividerand(size(X,2),0.8,0,0.20);
    Xtrain = X(:,trainInd);
    Ytrain = Y(:,trainInd);
    Xtest = X(:,testInd);
    Ytest = Y(:,testInd);
end

function netfig(net,filename)
    jframe = view(net);
    hFig = figure('Menubar','none', 'Position',[100 100 565 166]);
    jpanel = get(jframe,'ContentPane');
    [~,h] = javacomponent(jpanel);
    set(h, 'units','normalized', 'position',[0 0 1 1])

    %# close java window
    jframe.setVisible(false);
    jframe.dispose();
    set(hFig, 'PaperPositionMode', 'auto')
    saveas(hFig, filename)
%# close figure
close(hFig)
end