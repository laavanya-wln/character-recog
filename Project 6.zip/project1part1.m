function [result,best]=project1part1()
    [X1,X2,T,trainIdx,valIdx,testIdx,Xdata,Tdata] = createDataset();
    plotDatasets(X1,X2,T,trainIdx,valIdx,testIdx)
    [result,best] = fexperiment(Xdata,Tdata);
    %netfig(best.net,'bestregnet.png')
     Tpred = sim(best.net,[X1(testIdx) X2(testIdx)]')';
     figure,plotSurfaceQ1(X1(testIdx),X2(testIdx),Tpred,1:1000,[0.01 0.01],'Test Set Predictions Surface');
     %figure,plotContourQ1(X1(testIdx),X2(testIdx),Tpred-T(testIdx),1:1000,[0.01 0.01],'Test Set Errror Contours');
     %postregm(Tpred',T(testIdx)','');
     best.tr
end

function [result,best]=fexperiment(Xdata,Tdata)
    hidunits = [50];
    vperfs = zeros(max(size(hidunits)),1);
    for i=1:max(size(hidunits))
            [result(i).net, result(i).tr] =  ffnOperations(Xdata,Tdata,hidunits(i),'tansig');
            vperfs(i) = result(i).tr.best_vperf;
    end
    [~,bestidx] = min(vperfs);
    best= result(bestidx);
end

function [net,tr]=ffnOperations(X,T,numhidden,htransfn)
    net = feedforwardnet(numhidden);
    net.divideFcn = 'divideind';
    net.divideParam.trainInd = 1:1000;
    net.divideParam.valInd = 1001:2000;
    net.divideParam.testInd = 2001:3000;
    net.trainParam.showWindow=0;
    %net.trainParam.epochs=850;
    net.layers{1}.transferFcn = htransfn;
    net.layers{2}.transferFcn = 'purelin';
    [net,tr]=trainlm(net,X,T);
    %plotperform(tr)
end

function plotDatasets(X1,X2,T,trainIdx,valIdx,testIdx)
    %figure,plotSurfaceQ1(X1,X2,T,1:max(size(T)),[0.01 0.01],'Complete Dataset Surface');
    %figure,plotContourQ1(X1,X2,T,trainIdx,[0.01 0.01],'Training Set Contour');
    figure,plotSurfaceQ1(X1,X2,T,trainIdx,[0.01 0.01],'Training Set Surface');
    %figure,plotContourQ1(X1,X2,T,valIdx,[0.01 0.01],'Validation Set Contour');
    figure,plotSurfaceQ1(X1,X2,T,valIdx,[0.01 0.01],'Validation Set Surface');
    %figure,plotContourQ1(X1,X2,T,testIdx,[0.01 0.01],'Test Set Contour');
    figure,plotSurfaceQ1(X1,X2,T,testIdx,[0.01 0.01],'Test Set Surface');
end

function [X1,X2,T,trainIdx,valIdx,testIdx,Xdata,Tdata] = createDataset()
    data=load('Data_Problem1_regression.mat');
    X1 = data.X1;
    X2 = data.X2;
    sno = sort([0,6,9,0,8,0,9],'descend');
    digits = sno(1:5);
    T=(sum(bsxfun(@times,[data.T1 data.T2 data.T3 data.T4 data.T5],digits),2)/sum(digits));
    N = max(size(T));
    trainIdx = randsample(N,1000);
    valIdx = randsample(N,1000);
    testIdx = randsample(N,1000);
    Xdata = [X1(trainIdx) X2(trainIdx);X1(valIdx) X2(valIdx);X1(testIdx) X2(testIdx)]';
    Tdata = [T(trainIdx);T(valIdx);T(testIdx)]';
end

function [C,h]=plotContourQ1(X1,X2,T,idxs,step,titleStr)
    XVEC = X1(idxs);
    YVEC = X2(idxs);
    ZVEC = T(idxs);
    F=scatteredInterpolant(XVEC,YVEC,ZVEC);
    [Xq,Yq]=meshgrid(min(XVEC):step(1):max(XVEC),min(YVEC):step(2):max(YVEC));
    Vq = F(Xq,Yq);
    [C,h]=contour(Xq,Yq,Vq);
    xlabel('X_1');
    ylabel('X_2');
    zlabel('T');
    title(titleStr);
end

function h=plotSurfaceQ1(X1,X2,T,idxs,step,titleStr)
    XVEC = X1(idxs);
    YVEC = X2(idxs);
    ZVEC = T(idxs);
    F=scatteredInterpolant(XVEC,YVEC,ZVEC);
    [Xq,Yq]=meshgrid(min(XVEC):step(1):max(XVEC),min(YVEC):step(2):max(YVEC));
    Vq = F(Xq,Yq);
    h=surfc(Xq,Yq,Vq);
    xlabel('X_1');
    ylabel('X_2');
    zlabel('T');
    title(titleStr);
end


function netfig(net,filename)
    jframe = view(net);
    hFig = figure('Menubar','none', 'Position',[100 100 565 166]);
    jpanel = get(jframe,'ContentPane');
    [~,h] = javacomponent(jpanel);
    set(h, 'units','normalized', 'position',[0 0 1 1])

    %# close java window
    jframe.setVisible(false);
    jframe.dispose();
    set(hFig, 'PaperPositionMode', 'auto')
    saveas(hFig, filename)
%# close figure
close(hFig)
end