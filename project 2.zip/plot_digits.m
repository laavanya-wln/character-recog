function plot_digits(A,N,R)
  figure,hold on;
  plot_single(A,'Attractors',0);
  plot_single(N,'Noisy digits',10);
  plot_single(R,'Reconstructed noisy digits',20);
  ax = axes('position',[0,0,1,1],'visible','off');
  hold off;
end

function plot_single(Y,titleStr,pos)
    num_dig = size(Y,1);
    for i = 1:num_dig
        digit = Y(i,:);
        digit = reshape(digit,15,16)'; 
        h(i)=subplot(3,num_dig,i+pos);
        imshow(digit)
        if i == num_dig/2 +1
            tx = title(titleStr);
            set(tx,'fontweight','bold');
        end
    end 
    for i=1:max(size(h))
        p = get(h(i),'pos');
        p(2) = p(2) + 0.07;
        p(4) = p(4) - 0.07;
        set(h(i),'pos',p);
    end
end