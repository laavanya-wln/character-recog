numiters = [10 100 1000];
noisevalues = [0.5 1 5];
for i=1:max(size(noisevalues))
    filename=sprintf('hopdigit_n_%d.png',noisevalues(i)*10);
    hopdigit2(noisevalues(i),filename);
    close all;
end