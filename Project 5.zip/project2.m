function project2()
    [patterns,distpatterns] = prepareData();
    firstNExperiment(patterns,distpatterns,5,-1,1,1);
    incrementalExperiment(patterns,distpatterns)
    firstNExperimentScaled(patterns,distpatterns,25,-1,1,1);
end

function errors=incrementalExperiment(patterns,distpatterns)
    errors = zeros(size(patterns,1),1);
    for j=1:size(patterns,1)
        [errors(j),~,~]=firstNExperiment(patterns,distpatterns,j,-1,0,0);
    end
    p = size(patterns,1);
    N = 35;
    me = max(errors,'*');
    cap = N/(4*log(N));
    figure,hold on;
    plot(errors);
    line([cap cap],[0 120],'Color',[0,1,0]);
    xlabel('Number of Patterns');
    ylabel('Number of Pixel Errors');
    title('Hopfield Network Storage Capacity');
    hold off;
end


function [error,trainerror,disterror]=firstNExperimentScaled(patterns,distpatterns,n,numIters,plot,print)
    [error,trainerror,disterror] = testHopfieldNetScaled(patterns(1:n,:),distpatterns(1:n,:),5,7,5,1,numIters,plot);
    if print == 1
        fprintf('Error between original and distorted patterns (first %d) Before Hopfield Net: %d\n',n,disterror);
        fprintf('Error between original and attractor patterns (first %d) after training HopField Net: %d\n',n,trainerror);
        fprintf('Error between original and recollected distorted patterns (first %d) After %d test iterations: %d\n',n,numIters,error);
    end
end

function [error,trainerror,disterror]=firstNExperiment(patterns,distpatterns,n,numIters,plot,print)
    [error,trainerror,disterror] = testHopfieldNet(patterns(1:n,:),distpatterns(1:n,:),1,numIters,plot);
    if print == 1
        fprintf('Error between original and distorted patterns (first %d) Before Hopfield Net: %d\n',n,disterror);
        fprintf('Error between original and attractor patterns (first %d) after training HopField Net: %d\n',n,trainerror);
        fprintf('Error between original and recollected distorted patterns (first %d) After %d test iterations: %d\n',n,numIters,error);
    end
end

function [error,trainerror,disterror]=testHopfieldNetScaled(patterns,distpatterns,xsize,ysize,scale,roundpred,numIters,plotData)
    rpatterns = resizePatterns(patterns,ysize,xsize,scale);
    rdistpatterns = resizePatterns(distpatterns,ysize,xsize,scale);
    [rY,rtY] = HopfieldNetWrapper(rpatterns,rdistpatterns,numIters,roundpred);
    Y = resizePatterns(rY,ysize*scale,xsize*scale,1/scale);
    tY= resizePatterns(rtY,ysize*scale,xsize*scale,1/scale);
    [error,trainerror,disterror] = computeErrorsAndPlot(patterns,distpatterns,Y,tY,plotData);
end

function [error,trainerror,disterror]=testHopfieldNet(patterns,distpatterns,roundpred,numIters,plotData)
    [Y,tY] = HopfieldNetWrapper(patterns,distpatterns,numIters,roundpred);
    [error,trainerror,disterror] = computeErrorsAndPlot(patterns,distpatterns,Y,tY,plotData);
end

function [error,trainerror,disterror] = computeErrorsAndPlot(patterns,distpatterns,Y,tY,plotData)
    disterror = computeError(patterns,distpatterns);
    trainerror=computeError(tY,patterns);
    error=computeError(Y,patterns);
    if plotData == 1
        plotPatterns(patterns,'Original Characters');
        plotPatterns(distpatterns,'Distorted Characters');
        plotPatterns(Y,sprintf('Recollected Characters'));
    end
end

function [Y,tY] = HopfieldNetWrapper(patterns,distpatterns,numIters,roundpred)
    net=newhop(patterns');
    %netfig(net,sprintf('Hop%d.png',size(patterns,2)));
    [tY,~,~] = sim(net,size(patterns,1),[],patterns');
    tY = tY';
    if numIters == -1
        [Y,~,~] = sim(net,{size(distpatterns,1)},[],distpatterns');
        Y=Y{end}';
    else
        [Y,~,~] = sim(net,{size(distpatterns,1) numIters},[],distpatterns');
        Y=Y{1,numIters}';
    end
    if roundpred == 1
        Y = round(Y,0);
        tY=round(tY,0);
    else
        Y = sign(Y);
        tY=sign(tY);
    end
end

function error=computeError(patterns,distpatterns)
    errorMat = patterns.*distpatterns;
    errorMat(errorMat==0) = -1;
    errorMat(errorMat>0) = 0;
    errorMat(errorMat<0) = 1;
    error = sum(sum(double(errorMat)));
end

function [patterns,distpatterns] = prepareData()
    patterns = getCharacterPatterns();
    distpatterns = distortPatterns(patterns,3);
    plotPatterns(patterns,'Characters');
    plotPatterns(distpatterns,'Distorted Characters (3 bits)');
end


function plotPatterns(patterns,titleStr)
    allchars = zeros(7,180);
    for i=1:size(patterns,1)
        index = (i-1)*5+1;
        img = reshape(patterns(i,:),7,5);
        img(img==-1) = 0;
        allchars(:, index:(index+4))=img;
    end
    figure,subplot(3,1,1), subimage(allchars(:,1:60));title(titleStr);
    subplot(3,1,2), subimage(allchars(:,61:120))
    subplot(3,1,3), subimage(allchars(:,121:180));
end

function resizepatterns=resizePatterns(patterns,xsize,ysize,scalefactor)
    resizepatterns = zeros(size(patterns,1),round(scalefactor*scalefactor*size(patterns,2),0));
    for i=1:size(patterns,1)
        img = reshape(patterns(i,:),xsize,ysize);
        img(img==-1) = 0;
        resizedimg = imresize(img,scalefactor);
        resizedimg = round(resizedimg,0);
        reshaped = reshape(resizedimg,1,size(resizepatterns,2));
        reshaped(reshaped==0) = -1;
        resizepatterns(i,:) = reshaped;
    end
end

function distpatterns=distortPatterns(patterns,numbits)
    distpatterns = patterns;
    for i=1:size(patterns,1)
        distindxs = randsample(size(patterns,2),numbits);
        distpatterns(i,distindxs) = -1*patterns(i,distindxs);
    end
end

function patterns=getCharacterPatterns()
    % 31x35 Matrix containing patterns [l,a,v,n,y,A,B,C,...,X,Y,Z] 
    patterns = zeros(31,35);
   
    % Lowercase digits from la(a)v(a)ny(a) 

    l = [0    1    0    0    0;
         0    1    0    0    0;
         0    1    0    0    0;
         0    1    0    0    0;
         0    1    0    0    0;
         0    1    0    0    0;
         0    1    1    0    0];

    a = [0    0    0    0    0;
         0    0    0    0    0;
         0    1    1    1    0;
         1    0    0    1    0;
         1    0    0    1    0;
         1    0    0    1    0;
         1    1    1    1    1];


    v = [0    0    0    0    0;
         0    0    0    0    0;
         1    0    0    0    1;
         1    0    0    0    1;
         1    1    0    1    1;
         0    1    0    1    0;
         0    0    1    0    0];


    n = [0    0    0    0    0;
         0    0    0    0    0;
         1    1    1    1    0;
         1    0    0    1    0;
         1    0    0    1    0;
         1    0    0    1    0;
         1    0    0    1    0];


    y = [1    0    0    0    1;
         1    0    0    0    1;
         0    1    0    1    0;
         0    0    1    0    0;
         0    1    0    0    0;
         1    0    0    0    0;
         0    0    0    0    0];
     
     


    %Lowercase Letters
    lowerchars = [l a v n y];
    %Uppercase Letters
    chars = prprob;
    upperchars = zeros(7,size(chars,2)*5);
    for i=1:size(chars,2)
        index = (i-1)*5+1;
        upperchars(:,index:(index+4)) = reshape(chars(:,i),5,7)'; 
    end
    allchars = [lowerchars upperchars];
    %Make Pattern Vectors
    for i=0:5:150 
        index = round(i/5,0)+1;
        image = double(allchars(:,((i+1):(i+5))));
        image(image == 0) = -1;
        patterns(index,:)=reshape(image,1,35); 
    end
end

function netfig(net,filename)
    jframe = view(net);
    hFig = figure('Menubar','none', 'Position',[100 100 565 166]);
    jpanel = get(jframe,'ContentPane');
    [~,h] = javacomponent(jpanel);
    set(h, 'units','normalized', 'position',[0 0 1 1])

    %# close java window
    jframe.setVisible(false);
    jframe.dispose();
    set(hFig, 'PaperPositionMode', 'auto')
    saveas(hFig, filename)
%# close figure
close(hFig)
end

