clear
clc
close all

%%%%%%%%%%%
%algorlm.m
% A script comparing performance of 'trainlm' and 'trainbfg'
% trainbfg - BFGS quasi-Newton algorithm 
% trainlm - Levenberg - Marquardt
%%%%%%%%%%%

%generation of examples and targets
x=0:0.05:3*pi; y=sin(x.^2);
xtest = 0.01:0.06:3*pi;
noisy_y = y + rand(1, length(y));
%plot(noisy_y)
p=con2seq(x); t=con2seq(noisy_y); % convert the data to a useful format
q=con2seq(xtest);

%creation of networks
netgd=feedforwardnet(50,'traingd'); %gradient descent
netgda=feedforwardnet(50,'traingda'); %gradient descent with adaptive learning rate
netcgf=feedforwardnet(50,'traincgf'); %Fletcher-Reeves conjugate gradient algorithm
netcgp=feedforwardnet(50,'traincgp'); %Polak-Ribiere conjugate gradient algorithm
netbfg=feedforwardnet(50,'trainbfg'); %BFGS quasi Newton algorithm (quasi Newton)
netlm=feedforwardnet(50,'trainlm');  %Levenberg-Marquardt algorithm
netbr=feedforwardnet(50,'trainbr'); %bayesian reasoning

netgda.iw{1,1}=netgd.iw{1,1};  %set the same weights and biases for the networks 
netcgf.iw{1,1}=netgd.iw{1,1};
netcgp.iw{1,1}=netgd.iw{1,1};
netbfg.iw{1,1}=netgd.iw{1,1};
netlm.iw{1,1}=netgd.iw{1,1};
netbr.iw{1,1}=netgd.iw{1,1};

netgda.iw{2,1}=netgd.iw{2,1};  
netcgf.iw{2,1}=netgd.iw{2,1};
netcgp.iw{2,1}=netgd.iw{2,1};
netbfg.iw{2,1}=netgd.iw{2,1};
netlm.iw{2,1}=netgd.iw{2,1};
netbr.iw{2,1}=netgd.iw{2,1};

netgda.b{1}=netgd.b{1};
netcgf.b{1}=netgd.b{1};
netcgp.b{1}=netgd.b{1};
netbfg.b{1}=netgd.b{1};
netlm.b{1}=netgd.b{1};
netbr.b{1}=netgd.b{1};


netgda.b{2}=netgd.b{2};
netcgf.b{2}=netgd.b{2};
netcgp.b{2}=netgd.b{2};
netbfg.b{2}=netgd.b{2};
netlm.b{2}=netgd.b{2};
netbr.b{2}=netgd.b{2};

%training and simulation
netgd.trainParam.epochs=15;  % set the number of epochs for the training 
netgda.trainParam.epochs=15;
netcgf.trainParam.epochs=15;
netcgp.trainParam.epochs=15;
netbfg.trainParam.epochs=15;
netlm.trainParam.epochs=15;
netbr.trainParam.epochs=15;

netgd=train(netgd,p,t);   % train the networks
netgda=train(netgda,p,t);
netcgf=train(netcgf,p,t);
netcgp=train(netcgp,p,t);
netbfg=train(netbfg,p,t);
netlm=train(netlm,p,t);
netbr=train(netbr,p,t);
% 
% a11=sim(netgd,p); % simulate the networks with the input vector p
% a21=sim(netgda,p);
% a31=sim(netcgf,p);
% a41=sim(netcgp,p);
% a51=sim(netbfg,p);
% a61=sim(netlm,p);
% a71=sim(netbr,p);

a11=sim(netgd,q); % simulate the networks with the input vector p
a21=sim(netgda,q);
a31=sim(netcgf,q);
a41=sim(netcgp,q);
a51=sim(netbfg,q);
a61=sim(netlm,q);
a71=sim(netbr,q);

% netgd.trainParam.epochs=100;
% netgda.trainParam.epochs=100;
% netcgf.trainParam.epochs=100;
% netcgp.trainParam.epochs=100;
% netbfg.trainParam.epochs=100;
% netlm.trainParam.epochs=100;
% netbr.trainParam.epochs=100;
% 
% netgd=train(netgd,p,t);
% netgda=train(netgda,p,t);
% netcgf=train(netcgf,p,t);
% netcgp=train(netcgp,p,t);
% netbfg=train(netbfg,p,t);
% netlm=train(netlm,p,t);
% netbr=train(netbr,p,t);
% 
% a12=sim(netgd,p); 
% a22=sim(netgda,p);
% a32=sim(netcgf,p);
% a42=sim(netcgp,p);
% a52=sim(netbfg,p);
% a62=sim(netlm,p);
% a72=sim(netbr,p);
% 
% netgd.trainParam.epochs=1000;
% netgda.trainParam.epochs=1000;
% netcgf.trainParam.epochs=1000;
% netcgp.trainParam.epochs=1000;
% netbfg.trainParam.epochs=1000;
% netlm.trainParam.epochs=1000;
% netbr.trainParam.epochs=1000;
% 
% netgd=train(netgd,p,t);
% netgda=train(netgda,p,t);
% netcgf=train(netcgf,p,t);
% netcgp=train(netcgp,p,t);
% netbfg=train(netbfg,p,t);
% netlm=train(netlm,p,t);
% netbr=train(netbr,p,t);
% 
% a13=sim(netgd,p); 
% a23=sim(netgda,p);
% a33=sim(netcgf,p);
% a43=sim(netcgp,p);
% a53=sim(netbfg,p);
% a63=sim(netlm,p);
% a73=sim(netbr,p);

%plots
figure
%plot(x,y,'bx',x,cell2mat(a11),'r',x,cell2mat(a21),'g',x,cell2mat(a31),'b',x,cell2mat(a41),'y',x,cell2mat(a51),'c',x,cell2mat(a61),'k');
%plot(x,y,'bx',x,cell2mat(a12),'r',x,cell2mat(a22),'g',x,cell2mat(a32),'b',x,cell2mat(a42),'y',x,cell2mat(a52),'c',x,cell2mat(a62),'k');

plot(x,y,'bx',x,cell2mat(a11),'r',x,cell2mat(a21),'g',x,cell2mat(a31),'b',x,cell2mat(a41),'y',x,cell2mat(a51),'c',x,cell2mat(a61),'k');
title('1000 epochs');
legend('target','traingd','traingda','traincgf','traincgp','trainbfg','trainlm','Location','north');

% subplot(2,3,1);
% title('Algorithm - GD');
% postregm(cell2mat(a13),y);
% subplot(2,3,2);
% title('Algorithm - GDA');
% postregm(cell2mat(a23),y);
% subplot(2,3,3);
% title('Algorithm - CGF');
% postregm(cell2mat(a33),y);
% subplot(2,3,4);
% title('Algorithm - CGP');
% postregm(cell2mat(a43),y);
% subplot(2,3,5);
% title('Algorithm - BFG');
% postregm(cell2mat(a53),y);
% subplot(2,3,6);
% title('Algorithm - LM');
% postregm(cell2mat(a63),y);


